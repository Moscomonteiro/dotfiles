vim.g.mapleader = "\\"
--vim.g.maximizer_set_default_mapping = 0
vim.g.maximizer_default_mapping_key = '<leader><F3>'

vim.g.indentLine_char = '▏'
vim.g.indentLine_first_char = '▏'
vim.g.indentLine_showFirstIndentLevel = 1
