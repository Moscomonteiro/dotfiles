return{
    "szw/vim-maximizer"
}
