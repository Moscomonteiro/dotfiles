return{
    "preservim/nerdtree",
    config = function()
        vim.cmd([[NERDTree]])

        vim.keymap.set("n", "<leader>n", "<cmd>NERDTreeToggle<CR>")
    end,
}

