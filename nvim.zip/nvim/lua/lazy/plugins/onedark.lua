return{
    "navarasu/onedark.nvim",
    config = function()
        vim.cmd([[colorscheme onedark]])
    end,
}
